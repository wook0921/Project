package common.main.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import common.member.controller.MemberModel;
import common.member.service.MemberService;
import lombok.AllArgsConstructor;

@Controller
public class MainController {
	

	@GetMapping("/main.toy")
	public String main() {
		return "main_layout";
	}
	
	
}
