package common.member.mapper;


import java.util.List;

import common.member.controller.MemberModel;



public interface MemberMapper {

	/**이용자 회원가입시 memberModel 받아서 insert*/
	public void insertMember(MemberModel memberModel);
	
	/**아이디 중복검사*/
	public int idCheck(String email);
	
	/**핸드폰 중복검사*/
	public int mobileCheck(MemberModel memberModel);
	
	/**email 조건으로 이용자정보 1개 select*/
	public MemberModel memberDetail(String email);
	
	/**이용자 정보 수정 처리 update*/
	public void memberModify(MemberModel memberModel);
	
	/**이용자 탈퇴시 사용 update*/
	public void deleteMember(String email);
	
	/**비회원 제외한 전체 이용자 리스트 select*/
	public List<MemberModel> memberList ();
	
	
	
}