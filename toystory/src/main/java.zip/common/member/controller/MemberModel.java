package common.member.controller;

import java.sql.Date;
import lombok.Data;

@Data
public class MemberModel {

	private int mNum;
	private String mName;
	private String mEmail;
	private String mPassword;
	private Date mBirth;
	private String mMobile;
	private String mPhone;
	private String mZipcode;
	private String mAddress1;
	private String mAddress2;
	private int mPoint;
	private Date mRegdate;
	private String mRank;
	private String mAdult;
	private String mNote;
	
}