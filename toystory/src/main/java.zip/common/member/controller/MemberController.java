package common.member.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import common.member.service.MemberService;
import lombok.AllArgsConstructor;

@Controller
@AllArgsConstructor
public class MemberController {

	private MemberService memberService;

	@GetMapping("/join/join.toy")
	public String join() {
		return "join_form";
	}
	
	@PostMapping("join/join.toy")
	public String JoinPro(MemberModel memberModel) {
		memberService.insertMember(memberModel);
		
		
		return "redirect:main_layout";
	}
	
}
