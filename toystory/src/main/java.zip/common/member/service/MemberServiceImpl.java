package common.member.service;

import org.springframework.stereotype.Service;


import common.member.controller.MemberModel;
import common.member.mapper.MemberMapper;
import lombok.AllArgsConstructor;


@Service
@AllArgsConstructor
public class MemberServiceImpl implements MemberService{

	private MemberMapper memberMapper;
	
	@Override
	public void insertMember(MemberModel memberModel) {
		memberMapper.insertMember(memberModel);
		
	}

}
