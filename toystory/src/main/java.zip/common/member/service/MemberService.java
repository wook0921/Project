package common.member.service;

import common.member.controller.MemberModel;

public interface MemberService {

	public void insertMember(MemberModel memberModel);
}
